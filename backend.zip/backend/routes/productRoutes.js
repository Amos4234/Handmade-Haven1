const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const {
  getProducts,
  getProduct,
  createProduct,
  updateProduct,
  deleteProduct,
  getSpecialProducts // Make sure this exists in your controller
} = require('../controllers/productController');

// Public routes
router.get('/', getProducts);
router.get('/:id', getProduct);

// Protected routes
router.post('/', protect, authorize('artist', 'admin'), createProduct);
router.put('/:id', protect, authorize('artist', 'admin'), updateProduct);
router.delete('/:id', protect, authorize('admin'), deleteProduct);

// Special route
router.get('/special/featured', protect, authorize('admin', 'artist'), getSpecialProducts);

module.exports = router;