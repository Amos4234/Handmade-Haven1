const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Product name is required'],
    trim: true
  },
  description: {
    type: String,
    required: [true, 'Product description is required']
  },
  price: {
    type: Number,
    required: [true, 'Product price is required'],
    min: [0, 'Price must be at least 0']
  },
  category: {
    type: String,
    required: true,
    enum: ['jewelry', 'clothing', 'home-decor', 'art']
  },
  images: [{
    type: String,
    required: [true, 'At least one image is required']
  }],
  stock: {
    type: Number,
    default: 1,
    min: [0, 'Stock cannot be negative']
  },
  artist: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  featured: {
    type: Boolean,
    default: false
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
}, { timestamps: true });

module.exports = mongoose.model('Product', ProductSchema);